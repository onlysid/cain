<h1>This page does not exist.</h1>
<a href="/" class="btn">Go home...</a>