<h1>You cannot view this page.</h1>
<a href="/" class="btn">Go home...</a>